﻿namespace Abp.NServiceBus
{
    public class NServiceBusConsts
    {
        public const string LocalizationSourceName = "NServiceBus";
    }
}